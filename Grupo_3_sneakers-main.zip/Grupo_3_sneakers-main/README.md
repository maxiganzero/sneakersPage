### Tematica

Nuestro e-commerce sera una plataforma destinada a la venta de calzados,tanto deportivos,moda,casual o simplemente para el dia a dia,nuestro objetivo es apuntar a toda clase de publico que quiera marcar tendencia y estilo con los ultimos modelos lanzados por las marcas mas importantes del mundo,sea hombre,mujer,niño o adolescente,nuestro publico marcará tendencia.


### Referencias para nuestro e-commerce

* https://www.adidas.com.ar/ diseño de la pagina web
* https://www.tripstore.com.ar/ pagina multimarca con lo ultimo en tendencia
* https://www.sportfanatic.com.ar/ pagina multimarca con diseño claro,carrito de compras,barra de navegacion y busqueda
* https://plugmorestore.com/ diseño sencillo con productos destacados
*  https://www.moovbydexter.com.ar/ estilo basico de diseño en su pagina web.


### Integrantes del equipo

#### Ezequiel ganzero:
comenzando en el mundo de la programación,cursando en digital house,con muchas ganas de aprender este enorme universo.

#### Sol Bogado: 
Iniciando tambien en el mundo de la programación, atrasada pero con turbo

#### Axel Garrido:
Arrancando con muchas ganas en el mundo de la programacion de la mano de Digital House.

#### Anael Torres:  
Comenzando en este amplio mundo que es la programacion de la mano de Digital House.


## feedback Sprint 1
Solo no me agrado que no colocaran un footer en la home calificacion (10/10)


## Feedback Sprint 2
- Muchachos aunque tienen los items que exije el sprint , las vistas responsive estan mal optimizadas , sobre todo el login y el register , trabajen mas esa parte por favor  .
- calificacion (7/10)
